package com.cts.stockexchange.entity;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Table(name = "IPODetail")

public class IPODetail {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "IPO_id")
	private int id;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name="company",joinColumns={@JoinColumn(name="company_name")})
	private String companyname;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name="stockexchange",joinColumns={@JoinColumn(name="stockexchange_id")})
	private String stockExchange;
	
	@NotNull(message = " cannot be empty!")
	@Column(name = "IPO_price")
	private long pricePerShare;
	
	@NotNull(message = " cannot be empty!")
	@Column(name = "IPO_shares")
	private int noOfShares;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "IPO_open_date")
	private Date openDate;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "IPO_remarks")
	private String remarks;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCompanyname() {
		return companyname;
	}

	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}

	public String getStockExchange() {
		return stockExchange;
	}

	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}

	public long getPricePerShare() {
		return pricePerShare;
	}

	public void setPricePerShare(long pricePerShare) {
		this.pricePerShare = pricePerShare;
	}

	public int getNoOfShares() {
		return noOfShares;
	}

	public void setNoOfShares(int noOfShares) {
		this.noOfShares = noOfShares;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public IPODetail(int id, String companyname, String stockExchange, long pricePerShare, int noOfShares,
			Date openDate, String remarks) {
		super();
		this.id = id;
		this.companyname = companyname;
		this.stockExchange = stockExchange;
		this.pricePerShare = pricePerShare;
		this.noOfShares = noOfShares;
		this.openDate = openDate;
		this.remarks = remarks;
	}

	public IPODetail() {
		super();
		
	}
}

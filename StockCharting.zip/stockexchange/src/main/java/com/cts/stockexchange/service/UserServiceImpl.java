package com.cts.stockexchange.service;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.stockexchange.dao.UserDAOImpl;
import com.cts.stockexchange.entity.User;

import java.util.*;  
import javax.mail.*;  
import javax.mail.internet.*;  
import javax.activation.*; 

import java.util.List;

import javax.transaction.Transactional;

@Service
public class UserServiceImpl {

	
	@Autowired
	private UserDAOImpl userDao;
	
	@Transactional
	public String save(User user) {
		
		User foundUser = userDao.findByEmail(user.getEmail());
		if (foundUser != null) {
			return "Email already exists!";
		} else {
			String email = user.getEmail();
			   String to = email;//change accordingly  
			      String from = "akhilawasthi07@gmail.com";
			      String host = "localhost";
			  
			     //Get the session object  
			      Properties properties = System.getProperties();  
			      properties.setProperty("mail.smtp.host", host);  
			      Session session = Session.getDefaultInstance(properties);  
			  
			     //compose the message  
			      try{  
			         MimeMessage message = new MimeMessage(session);  
			         message.setFrom(new InternetAddress(from));  
			         message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
			         message.setSubject("confirmation mail");  
			         message.setText("Hello, this is example of sending email  ");  
			  
			         // Send message  
			         Transport.send(message);  
			         System.out.println("message sent successfully....");  
			  
			      }catch (MessagingException mex) {mex.printStackTrace();}  
			   }  
		
			userDao.save(user);	
		return "saved";
	}
      
	
}








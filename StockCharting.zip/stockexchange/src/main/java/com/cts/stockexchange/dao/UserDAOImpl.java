package com.cts.stockexchange.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.stockexchange.entity.User;

@Repository("UserDAO")
public class UserDAOImpl implements UserDAO{

	@Autowired
	SessionFactory sessionFactory;
	
	/**
	 * method to save new user in database.
	 * @param user
	 */
	public void save(User user) {
		Session session = sessionFactory.openSession();
		session.save(user);
		session.close();
	}
	
	
	
	/**
	 * method to search user by id.
	 * @param email
	 * @return
	 */
	public User findByEmail(String email) {
		User result = null;
		try{
			Session session = sessionFactory.openSession();		
			List<User> users = session.createQuery("from User").list();
			
			for (User user : users) {
				if(user.getEmail().equals(email)) {
					result = user;
				}
			}
             if(result==null){
				
				System.out.println("User does not exist");
			}
			session.close();
			//return result;
			
		}catch(Exception exception){
			exception.printStackTrace();
		}
		return result;
	}
	
	
}

package com.cts.stockexchange.dao;

public interface UserDAO {
  
}

package com.cts.stockexchange.service;

public interface UserService {

}

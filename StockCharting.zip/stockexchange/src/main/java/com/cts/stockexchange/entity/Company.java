package com.cts.stockexchange.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
@Table(name = "Company")
public class Company {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Company_id")
	private int id;

	@NotNull(message = "Name cannot be empty!")
	@Column(name = "Company_name")
	@Size(max = 70, message = "Name cannot exceed 70 characters!")
	private String companyName;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "Company_turnover")
	private double turnover;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "Company_ceo")
	private String ceo;
	
	@NotNull(message = "Names cannot be empty!")
	@Column(name = "Company_directors")
	private ArrayList<String> boardOfDirectors;
	
//	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//	@Column(name = "Company_directors")
//	private List<StockExchange> stockExchanges;
	
	
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name = "StockExchange", joinColumns = { @JoinColumn(name = "StockExchange_id") })
	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private List<StockExchange> stockExchanges;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinTable(name="sector",joinColumns={@JoinColumn(name="sector_id")})
	private String sector;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "Company_about")
	private String about;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "Company_stockCode")
	private String stockCode;


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public double getTurnover() {
		return turnover;
	}

	public void setTurnover(double turnover) {
		this.turnover = turnover;
	}

	public String getCeo() {
		return ceo;
	}

	public void setCeo(String ceo) {
		this.ceo = ceo;
	}

	public ArrayList<String> getBoardOfDirectors() {
		return boardOfDirectors;
	}

	public void setBoardOfDirectors(ArrayList<String> boardOfDirectors) {
		this.boardOfDirectors = boardOfDirectors;
	}

	public List<StockExchange> getStockExchanges() {
		return stockExchanges;
	}

	public void setStockExchanges(List<StockExchange> stockExchanges) {
		this.stockExchanges = stockExchanges;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public String getStockCode() {
		return stockCode;
	}

	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}
	
	public Company(int id, String companyName, double turnover, String ceo, ArrayList<String> boardOfDirectors,
			List<StockExchange> stockExchanges, String sector, String about, String stockCode) {
		super();
		this.id = id;
		this.companyName = companyName;
		this.turnover = turnover;
		this.ceo = ceo;
		this.boardOfDirectors = boardOfDirectors;
		this.stockExchanges = stockExchanges;
		this.sector = sector;
		this.about = about;
		this.stockCode = stockCode;
	}

	public Company() {
		super();
	}

}
